<template>
<div>
 
 <div class="container row text-center">
            <ul class="list-group">
                <li class="list-group-item">
                    <!-- @{{item.name.first}} @{{item.name.last}} -->
                    <!-- @{{user.nombre}} @{{user.apellido}} -->
                </li>
            </ul>
        </div>

</div>
</template>

<script>
export default {
 }

</script>