<template>
 <div class="justify-content-center" style="margin-top:10em;text-align:center;">
       <div class="jumbotron jumbotron-fluid" style="background-color:#212529;">
         <a href="https://lotusestudi.com" style="color:white;">Samuel Chicón</a> 
       </div>
  </div>
</template>
<script>
export default {
    
}
</script>