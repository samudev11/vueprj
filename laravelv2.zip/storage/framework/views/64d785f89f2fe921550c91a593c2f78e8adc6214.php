<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->        
        <link rel="stylesheet" href="<?php echo e(asset('./css/app.css')); ?>">
        
        
    </head>
   
    <div id="app-nav">
        <navbar-menu></navbar-menu>
    </div>
    <div id="app" class="content"><!--La equita id debe ser app, como hemos visto en app.js-->
    

        <body class="antialiased">     
        
                <?php echo $__env->yieldContent('content'); ?>                                         
                
            <footer-section></footer-section>
        </body>


    </div>     
    <!-- App script -->   
    <script src="<?php echo e(asset('js/app.js')); ?>"></script> <!--Añadimos el js generado con webpack, donde se encuentra nuestro componente vuejs-->
</html><?php /**PATH C:\xampp\htdocs\laravelv2\resources\views/layouts/layout.blade.php ENDPATH**/ ?>