<?php $__env->startSection('title', 'SCD - Laravel8--Vuejs App'); ?>

<?php $__env->startSection('content'); ?>

<h1>Tarea registrada bien</h1>


<ul class="list-group list-group-flush">
    <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>            
        <li class="list-group-item">
            <label class="checkbox-inline float-left">
                <input type="checkbox" style="margin-right:1em;"><?php echo e($tarea->descripcion); ?>

            </label>                               
            
            <button type="button" class="btn btn-outline-danger btn-sm float-right" v-on:click="EliminarTarea(tarea)">Eliminar</button>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<ul class="pagination">
    <?php echo e($tareas->links()); ?>

</ul>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelv2\resources\views/tarea.blade.php ENDPATH**/ ?>